// 讨论回复模型
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const User = require('./User');
const Discussion = require('./Discussion');

const DiscussionReply = sequelize.define('DiscussionReply', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  discussionId: {
    type: DataTypes.INTEGER,
    field: 'discussion_id',
    allowNull: false
  },
  userId: {
    type: DataTypes.INTEGER,
    field: 'user_id',
    allowNull: false
  },
  userName: {
    type: DataTypes.STRING(100),
    field: 'user_name',
    allowNull: false
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: false
  }
}, {
  tableName: 'discussion_replies',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false
});

// 关联关系
DiscussionReply.belongsTo(Discussion, { foreignKey: 'discussionId', as: 'discussion' });
DiscussionReply.belongsTo(User, { foreignKey: 'userId', as: 'sender' });

module.exports = DiscussionReply;